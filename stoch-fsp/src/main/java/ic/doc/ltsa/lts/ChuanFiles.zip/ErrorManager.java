package ic.doc.ltsa.lts;

import ic.doc.ltsa.common.iface.ICompositeState;
import ic.doc.ltsa.common.iface.IEventState;
import ic.doc.ltsa.common.iface.LTSOutput;
import ic.doc.ltsa.lts.CompactState;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class ErrorManager {

	public CompactState mergeErrors(CompactState machine) {
		System.out.println("In merge error ------------------------");
		List<IEventState> newStatesList = new LinkedList<IEventState>();
		
		for(int i=0; i<machine.getMaxStates(); i++ ) {
			double prob = 0;
			int event = 0;
			int nxt = 0;
			boolean hasError = false;
			IEventState newTr = null;
			if( machine.getStates()[i]!= null ) { 
				for(Enumeration e = machine.getStates()[i].elements(); e.hasMoreElements();) {
					IEventState st = (IEventState)e.nextElement();
					System.out.println("action --------------------------------------------"+st.getEvent());

					if (st.getNext() != -1) {
						newTr = EventState.add(newTr,new EventState(st.getEvent(),st.getNext(),null,null,st.getProb()));		
					} else {
						prob += st.getProb();
						hasError = true;
						event = st.getEvent();
						nxt = st.getNext();
					}
					
					
				}
				
				if (hasError) {
					newTr = EventState.add(newTr,new EventState(event,nxt,null,null,prob));
				}
					
			}
			
			newStatesList.add(newTr);
		}
	
		CompactState m = new CompactState();
	     m.setName(machine.getName());
	     
	     m.alphabet = machine.alphabet.clone();
	     for (int i=0; i<m.alphabet.length; i++) {
	    	 	if(m.alphabet[i].matches("error_.*")) {
	    	 		System.out.println("Matches       "+m.alphabet[i]);
	    	 		m.alphabet[i] = "error_"+machine.getName();
	    	 	}
	     }
	     
	     m.maxStates = newStatesList.size();
	     m.setStates(new EventState[m.maxStates]);
	     int stateNum = 0;
	     for (IEventState st : newStatesList) {
	        m.getStates()[stateNum] = st;
	        stateNum++;
	      }
	         	   
	      return m;
	}  
}
